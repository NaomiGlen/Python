print("Hello World!")

name = "Naomi"
print("Hello",name,"!")
print("Hello "+name+"!")

num=13
print("Hello",num,"!")
print(f"Hello "+str(num)+"!")

fave_food1= "steak"
fave_food2= "potatoes"
print("I love to eat {} and {}.".format(fave_food1,fave_food2))
print(f"I love to eat {fave_food1} and {fave_food2}.")