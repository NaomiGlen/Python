from flask import Flask
app = Flask(__name__)
app.secret_key="tHaT h0nk3y TonK b@doNka-d0nk!"