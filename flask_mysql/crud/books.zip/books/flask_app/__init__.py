from flask import Flask
app = Flask(__name__)
app.secret_key = "@ run-RuN-rUn-RUN RuN@w@yYyyY!"